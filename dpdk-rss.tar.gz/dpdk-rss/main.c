/* SPDX-License-Identifier: BSD-3-Clause
 * Copyright(c) 2010-2016 Intel Corporation
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <inttypes.h>
#include <sys/types.h>
#include <sys/queue.h>
#include <netinet/in.h>
#include <setjmp.h>
#include <stdarg.h>
#include <ctype.h>
#include <errno.h>
#include <getopt.h>
#include <signal.h>
#include <arpa/inet.h>
#include <stdbool.h>

#include <rte_common.h>
#include <rte_log.h>
#include <rte_malloc.h>
#include <rte_memory.h>
#include <rte_memcpy.h>
#include <rte_eal.h>
#include <rte_launch.h>
#include <rte_atomic.h>
#include <rte_cycles.h>
#include <rte_prefetch.h>
#include <rte_lcore.h>
#include <rte_per_lcore.h>
#include <rte_branch_prediction.h>
#include <rte_interrupts.h>
#include <rte_random.h>
#include <rte_debug.h>
#include <rte_ether.h>
#include <rte_ethdev.h>
#include <rte_mempool.h>
#include <rte_mbuf.h>
#include <rte_string_fns.h>
#include <rte_ip.h>
#include <rte_thash.h>

#include "rss.h"

static volatile bool force_quit;

static void
signal_handler(int signum)
{
	if (signum == SIGINT || signum == SIGTERM) {
		printf("\n\nSignal %d received, preparing to exit...\n",
				signum);
		force_quit = true;
	}
}

int
main(int argc, char **argv)
{
	(void)argc;
	(void)argv;
	
	uint32_t hash;

	signal(SIGINT, signal_handler);
	signal(SIGTERM, signal_handler);
	signal(SIGPIPE, signal_handler);
	
	char strsrcIpv4[16] = {"200.81.2.10"};
	char strdstIpv4[16] = {"200.82.1.1"};
	
    char strsrcIPV6[64] = {"2409:891e:80:230b::86"};
    char strdstIPV6[64] = {"2409:891e:80:230b:ecd7:fca4:2de9:a288"};

	// 1.rss_key��ʼ��
	rss_init();

	// 2.�Ӳ����л�ȡ��Ԫ����Ϣ(ip���ͺ�Դ/Ŀ��IP)
	uint32_t input_len;
	void *tuple;
	int ip_type = 0;
	struct rte_ipv4_tuple ipv4_tuple;
	struct rte_ipv6_tuple ipv6_tuple;
	struct rte_ipv4_hdr ipv4_hdr;
	struct rte_ipv6_hdr ipv6_hdr;
	memset(&ipv4_hdr, 0, sizeof(struct rte_ipv4_hdr));
	memset(&ipv6_hdr, 0, sizeof(struct rte_ipv6_hdr));
	memset(&ipv4_tuple, 0, sizeof(struct rte_ipv4_tuple));
	memset(&ipv6_tuple, 0, sizeof(struct rte_ipv6_tuple));

	inet_pton(AF_INET, strsrcIpv4, &ipv4_hdr.src_addr);
	inet_pton(AF_INET, strdstIpv4, &ipv4_hdr.dst_addr);

	inet_pton(AF_INET6, strsrcIPV6, &ipv6_hdr.src_addr);
	inet_pton(AF_INET6, strdstIPV6, &ipv6_hdr.dst_addr);

	//printf("src: %u, dst: %u\n", ipv4_hdr.src_addr, ipv4_hdr.dst_addr);

	ip_type = 6;
	
	if(ip_type == 4) {
		ipv4_tuple.src_addr = rte_be_to_cpu_32(ipv4_hdr.src_addr);
		ipv4_tuple.dst_addr = rte_be_to_cpu_32(ipv4_hdr.dst_addr);
		tuple = &ipv4_tuple;
		input_len = RTE_THASH_V4_L3_LEN;
	} else if(ip_type == 6) {
		rte_thash_load_v6_addrs(&ipv6_hdr, (union rte_thash_tuple *)&ipv6_tuple);
		tuple = &ipv6_tuple;
		input_len = RTE_THASH_V6_L3_LEN;
	} else {
		printf("IP type Error!\n");
	}
	// printf("input_len = %u\n", input_len);
	
	// 3.��ȡRSSֵ
	hash = rss_hash_data((uint32_t *)tuple, input_len);	
	
	printf("hash = %u\n", hash);

	return 0;
}
