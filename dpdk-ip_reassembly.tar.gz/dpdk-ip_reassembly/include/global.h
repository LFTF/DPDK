/* SPDX-License-Identifier: BSD-3-Clause
 * Copyright(c) 2010-2016 Intel Corporation
 */

#ifndef __GLOBAL__
#define __GLOBAL__

int rx_queue_pkts[32];

#endif  /* __GLOBAL__ */
